# Rubric (draft): BUS 3306 AI Project

What gets checked at each checkpoint. Points are a suggestion, and the instructor sets the final version.

| # | Checkpoint | What we look for | Points |
|---|---|---|---|
| 1 | Interview | `project-brief.md` is specific: a real anchor, a clear angle, and a named audience | 10 |
| 2 | Build | The work file runs, the numbers make sense, and the student made at least one judgment call | 20 |
| 3 | One-pager | It shows a clear headline, a chart, and sources. It works on a phone and doesn't look like a template | 15 |
| 4 | Fact-check | Every number has a source, 3 are checked by the student, and one AI mistake is logged and fixed | 20 |
| 5 | Make it yours | At least 2 student-led changes, and the work fits the student's goals | 10 |
| 6 | Pitch deck | 6 slides, each under 30 words. Slide 5 is honest about AI | 15 |
| 7 | Reflect | 3 sentences in the student's own words that show real thought | 10 |
| | **Total** | | **100** |

**What to turn in:** the `my-work/` folder, zipped.
