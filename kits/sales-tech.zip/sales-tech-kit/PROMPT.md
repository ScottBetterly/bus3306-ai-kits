# Using this kit in ChatGPT (instead of Codex)

Use this only if Codex isn't working for you.

**Step 1.** In ChatGPT, start a new Project, or a new chat.

**Step 2.** Upload these files: `AGENTS.md`, `templates/deck-template.html`, and everything in `sample-data/`.

**Step 3.** Paste this message and send it:

```
You are my guide for this project. Follow AGENTS.md exactly. Ask me
one question at a time, in simple words.

You can't save files on my computer, so when AGENTS.md says to save a
file, give me the full contents in one code block and tell me the file
name. I'll save it into my my-work folder.

You also can't edit progress.html, so after every checkpoint print the
progress line and tell me which checkpoint to tick off.

Let's start.
```

**Tip:** To open an `.html` file you saved, double-click it. It opens in your browser.
