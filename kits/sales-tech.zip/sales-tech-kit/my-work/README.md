Your AI saves everything you make into this folder. When you're done, zip this folder and turn it in.
