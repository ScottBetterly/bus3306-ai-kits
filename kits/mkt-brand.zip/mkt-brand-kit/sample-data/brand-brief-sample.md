# Brand brief: Golden Coast Coffee (SAMPLE: not a real company)

- **What they sell:** cold brew, espresso drinks, and canned coffee. 780 cafés on the West Coast.
- **Who buys now:** office workers aged 30 to 50, mostly on the way to work.
- **Brand voice:** warm, sunny, a little surfer-casual, never snobby.
- **Problem:** few college students buy it. They think it's "my parents' coffee."
- **New product:** "Tide Line," a canned oat-milk cold brew sold in grocery stores, $3.49.
- **Competitors:** big national chains, energy drinks, and local indie cafés.
- **What they're known for:** baristas who learn your name, and beach-themed stores.
