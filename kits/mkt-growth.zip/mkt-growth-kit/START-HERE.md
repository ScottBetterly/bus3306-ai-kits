# Start here: Growth & Digital: Growth Plan

**Marketing Management · BUS 3306 AI Project**

## What you'll make
You'll pick a brand, find where it's losing customers, and plan how to fix it. You'll get a step-by-step customer map, a 30-day content calendar, and a test that compares two versions to see which works better.

You'll end up with 4 things you can show an employer:
1. **A work file:** the real analysis (a spreadsheet plus a short memo).
2. **A one-pager:** a web page that shows your work at a glance.
3. **A pitch deck:** 6 slides you could present in 3 minutes.
4. **A reflection:** 3 sentences on how you used AI.

It takes about 1.5 hours in total, and you can stop and come back any time.

## How to start (Codex)
1. Unzip this kit. On a Mac, double-click it. On Windows, right-click it and choose **Extract All**.
2. Open Codex, then open **this folder**. `AGENTS.md` should sit right inside it.
3. Type: **Let's start.**
4. Answer its questions. Short answers are fine. If you're unsure, type **Help me pick.**

## How to start (ChatGPT, if Codex isn't working)
Open `PROMPT.md` and follow its 3 steps.

## See your progress
Double-click **`progress.html`** to open your tracker. It shows the 7 checkpoints and what's next. Refresh the page after each step.

## Stuck? Type one of these
- `Help me pick.`: get 3 suggestions picked for you, like companies or ideas
- `I'm stuck.`: get 2 full project ideas built around you
- `Where am I?`: see your progress and next step
- `Check my work.`: find out what's missing
- `Explain that simpler.`: hear it again in plain words
- `Redo this step.`: start the current step over
